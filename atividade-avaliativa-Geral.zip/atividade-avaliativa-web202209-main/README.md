# atividade-avaliativa-web202209
Este repositório é para a execução da atividade avaliativa da disciplina de padrões web do prof Araya
Grupo
Andréia Nayane
Carlos Felipe 
Célida
Lucas Matias
Luy
